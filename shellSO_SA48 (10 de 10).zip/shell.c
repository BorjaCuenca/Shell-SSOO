/*Borja Cuenca Páez*/
/**
 * Linux Job Control Shell Project
 *
 * Operating Systems
 * Grados Ing. Informatica & Software
 * Dept. de Arquitectura de Computadores - UMA
 *
 * Some code adapted from "OS Concepts Essentials", Silberschatz et al.
 *
 * To compile and run the program:
 * $ gcc shell.c job_control.c -o shell
 * $ ./shell
 * (then type ^D to exit program)
 **/

#include "job_control.h" /* Remember to compile with module job_control.c */

#define MAX_LINE 256 /* 256 chars per line, per command, should be enough */

job* job_list;

/**
 * Manejador para la señal SIGCHLD
 */
void sigchld_handler(int sig) {
    block_SIGCHLD();
    job* iter = get_iterator(job_list);
    pid_t pid_wait;
    enum status status_res;
    int status, info;

    while(has_next(iter)) {
        job* the_job = next(iter);
        pid_wait = waitpid(the_job->pgid, &status, WUNTRACED | WNOHANG | WCONTINUED);

        if (pid_wait == the_job->pgid) {
            status_res = analyze_status(status, &info);

            printf("\nBackground pid: %d, command: %s, %s, info: %d\n", the_job->pgid, the_job->command, status_strings[status_res], info);

            if (status_res == SUSPENDED) {
                the_job->state = STOPPED;
            } else if (status_res == CONTINUED) {
                the_job->state = BACKGROUND;
            } else { // SIGNALED o EXITED
                delete_job(job_list, the_job);
            }
        } 
		else if (pid_wait == -1){
			perror("Wait error");
		}
    }
    unblock_SIGCHLD();
}

int main(void)
{
    char inputBuffer[MAX_LINE]; /* Buffer to hold the command entered */
    int background; /* Equals 1 if a command is followed by '&' */
    char *args[MAX_LINE/2]; /* Command line (of 256) has max of 128 arguments */

    int pid_fork, pid_wait;
    int status;
    enum status status_res;
    int info;

    FILE *in_file, *out_file;

    ignore_terminal_signals();
    job_list = new_list("Job list");
    signal(SIGCHLD, sigchld_handler);

    while (1) /* Program terminates normally inside get_command() after ^D is typed */
    {
        printf("COMMAND->");
        fflush(stdout);
        get_command(inputBuffer, MAX_LINE, args, &background);

        char *file_in, *file_out;
        parse_redirections(args, &file_in, &file_out);

        if(args[0] == NULL) continue; /* Do nothing if empty command */

        if (!strcmp(args[0], "exit")) {
            printf("Bye!\n");
            exit(EXIT_SUCCESS);

        } 
		else if (!strcmp(args[0], "cd")) {
            if (args[1] != NULL){
				chdir(args[1]);
			}
			else {
				char *home = getenv("HOME"); // Obtener el directorio home desde las variables de entorno
				if (home == NULL) {
					printf("Error: HOME not set\n");
					continue;
				}
				chdir(home);
			}
        } 
		else if (!strcmp(args[0], "jobs")) {
            if (list_size(job_list) > 0) {
                block_SIGCHLD();
                print_job_list(job_list);
                unblock_SIGCHLD();
            } else {
                printf("\nNo Background or Suspended tasks\n");
            }

        } else if (!strcmp(args[0], "bg")) {
            int pos = 1;
            if (args[1] != NULL) pos = atoi(args[1]);

            block_SIGCHLD();
            job* the_job = get_item_bypos(job_list, pos);

            if (the_job != NULL && the_job->state == STOPPED) {
                the_job->state = BACKGROUND;
                killpg(the_job->pgid, SIGCONT);
            }
            unblock_SIGCHLD();

        } else if (!strcmp(args[0], "fg")) {
            int pos = 1;
            if (args[1] != NULL) pos = atoi(args[1]);

            block_SIGCHLD();
            job* the_job = get_item_bypos(job_list, pos);
            unblock_SIGCHLD();

            if (the_job != NULL) {
                set_terminal(the_job->pgid);
                pid_t the_job_pgid = the_job->pgid;
                char* the_job_name = strdup(the_job->command);

                if (the_job->state == STOPPED) {
                    killpg(the_job->pgid, SIGCONT);
                }

                block_SIGCHLD();
                delete_job(job_list, the_job);
                unblock_SIGCHLD();

                pid_wait = waitpid(the_job_pgid, &status, WUNTRACED);
                set_terminal(getpid());

                if (pid_wait == the_job_pgid) {
                    status_res = analyze_status(status, &info);
                    printf("\nForeground pid: %d, command: %s, %s, info: %d\n", the_job_pgid, the_job_name, status_strings[status_res], info);

                    if (status_res == SUSPENDED) {
                        block_SIGCHLD();
                        add_job(job_list, new_job(pid_wait, the_job_name, STOPPED));
                        unblock_SIGCHLD();
                    }

                } else if (pid_wait == -1) {
                    printf("Wait error");
                }
            }

        } else {
            pid_fork = fork();

            if (pid_fork > 0) { // Parent
                new_process_group(pid_fork);

                if (!background) {
                    set_terminal(pid_fork);
                    pid_wait = waitpid(pid_fork, &status, WUNTRACED);
                    set_terminal(getpid());

                    if (pid_wait == pid_fork) {
                        status_res = analyze_status(status, &info);
                        printf("\nForeground pid: %d, command: %s, %s, info: %d\n", pid_fork, args[0], status_strings[status_res], info);

                        if (status_res == SUSPENDED) {
                            block_SIGCHLD();
                            add_job(job_list, new_job(pid_wait, args[0], STOPPED));
                            unblock_SIGCHLD();
                        }
                    } else if (pid_wait == -1) {
                        printf("Wait error");
                    }

                } else {
                    printf("\nBackground job running... pid: %d, command: %s\n", pid_fork, args[0]);
                    block_SIGCHLD();
                    add_job(job_list, new_job(pid_fork, args[0], BACKGROUND));
                    unblock_SIGCHLD();
                }

            } else if (pid_fork == 0) { // Child
                new_process_group(getpid());
                if (!background) set_terminal(getpid());
                restore_terminal_signals();

                if (file_in) {
                    if (NULL == (in_file = fopen(file_in, "r")) || dup2(fileno(in_file), fileno(stdin)) == -1) {
                        perror("Error");
                        exit(EXIT_FAILURE);
                    }
                }

                if (file_out) {
                    if (NULL == (out_file = fopen(file_out, "w")) || dup2(fileno(out_file), fileno(stdout)) == -1) {
                        perror("Error");
                        exit(EXIT_FAILURE);
                    }
                }

                execvp(args[0], args);
                printf("\nError, command not found: %s\n", args[0]);
                exit(EXIT_FAILURE);

            } else {
                printf("Fork error.\n");
            }
        }
    } /* End while */
}